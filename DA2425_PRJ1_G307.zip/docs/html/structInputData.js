var structInputData =
[
    [ "in", "structInputData.html#aff97a66a0e9ee32075df79a7f1356d40", null ],
    [ "readInputFile", "structInputData.html#a29ba6946f6e69d6bc9577cf7398a2d32", null ],
    [ "readTerminal", "structInputData.html#a238297e391e04d40bee5584f9a0f0d11", null ]
];