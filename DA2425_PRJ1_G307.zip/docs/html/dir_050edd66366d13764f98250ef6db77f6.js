var dir_050edd66366d13764f98250ef6db77f6 =
[
    [ "algorithms", "dir_8160e34c50d09853ef988b56ff986319.html", "dir_8160e34c50d09853ef988b56ff986319" ],
    [ "data_structures", "dir_711de0d3e4dbdddc1fa484232f34384f.html", "dir_711de0d3e4dbdddc1fa484232f34384f" ]
];