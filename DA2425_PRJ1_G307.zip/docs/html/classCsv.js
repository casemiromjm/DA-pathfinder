var classCsv =
[
    [ "getData", "classCsv.html#a34edd8c6ea9b3de5dc6e99913d040c05", null ],
    [ "readCSV", "classCsv.html#af0215acb99738bafc790557456f35048", null ]
];