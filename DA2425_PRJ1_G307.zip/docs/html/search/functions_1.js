var searchData=
[
  ['getdata_0',['getData',['../classCsv.html#a34edd8c6ea9b3de5dc6e99913d040c05',1,'Csv']]]
];
